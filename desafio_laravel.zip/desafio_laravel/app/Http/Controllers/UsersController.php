<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Users;

class UsersController extends Controller
{
    // public function index(){
    //     $userss = Users::all();
    //     return view('users.index' , ['users' => $userss]);
        
    // }

    public function index(Request $request) {
    $search = $request->query('search');
    if ($search) {
        $users = Users::where('name', 'LIKE', "%{$search}%")->get();
    } else {
        $users = Users::all();
    }

    return view('users.index', compact('users'));
    }

    public function create(){
        return view('users.create');
    }

    public function register(Request $request){
        $data = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required|numeric',
            'areaI' => 'required',
            'message' => 'nullable'

        ]);
        
        $newUsers = Users::create($data);

        return redirect(route('users.index'));
    }

    public function edit(Users $users){
        return view('users.edit', ['users' => $users]);
    }

    public function update(Users $users, Request $request){
        $data = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required|numeric',
            'areaI' => 'required',
            'message' => 'nullable'

        ]);


        $users->update($data);
        return redirect(route('users.index'))->with('success', 'User Updated Successfully');
    }

    public function delete(Users $users){
        $users->delete();
        return redirect(route('users.index'))->with('success', 'User Deleted Successfully');
    }
}