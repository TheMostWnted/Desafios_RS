<template>
  <div id="app">
    <MultistepForm />
  </div>
</template>

<script>
import MultistepForm from './views/MultistepForm.vue';

export default {
  name: 'App',
  components: {
    MultistepForm
  }
}
</script>