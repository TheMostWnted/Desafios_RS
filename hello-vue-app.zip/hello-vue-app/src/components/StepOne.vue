<template>
  <div class="form-step">
    <div class="form-group">
      <label for="name">Nome Completo:</label>
      <input type="text" id="name" :value="formData.name" @input="$emit('update:name', $event.target.value)" class="form-control" />
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" id="email" :value="formData.email" @input="$emit('update:email', $event.target.value)" class="form-control" />
    </div>
  </div>
</template>

<script>
export default {
  props: ['formData']
}
</script>

<style scoped>
.form-step {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.form-group {
  width: 100%;
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

.form-control {
  width: 163%;
  padding: 15px;
  font-size: 18px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
</style>
