<template>
  <div>
    <div>
      <label>Deseja adicionar algo à sua candidatura? (opcional)</label>
      <textarea :value="formData.message" @input="$emit('update:message', $event.target.value)" class="large-textarea"></textarea>
    </div>
    <div class="terms-container">
      <button @click="openModal" class="terms-button">Ver Termos e Condições</button>
      <div class="checkbox-container">
        <input type="checkbox" :checked="formData.termsAccepted" @change="$emit('update:termsAccepted', $event.target.checked)" required />
        <label>Li e aceito os termos e condições</label>
      </div>
    </div>

    <!-- Modal -->
    <div v-if="showModal" class="modal">
      <div class="modal-content">
        <span class="close" @click="closeModal">&times;</span>
        <h2>Termos e Condições</h2>
        <p>Aqui estão os termos e condições...</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['formData'],
  data() {
    return {
      showModal: false
    };
  },
  methods: {
    openModal() {
      this.showModal = true;
    },
    closeModal() {
      this.showModal = false;
    }
  }
}
</script>

<style scoped>
.large-textarea {
  width: 100%;
  height: 150px;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.terms-container {
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.terms-button {
  margin-bottom: 10px;
}

.checkbox-container {
  display: flex;
  align-items: center;
}

.modal {
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
  background-color: #fff;
  padding: 20px;
  border-radius: 4px;
  width: 80%;
  max-width: 500px;
  position: relative;
}

.close {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 24px;
  cursor: pointer;
}
</style>