<template>
  <div class="form-step">
    <div class="form-group">
      <label for="phone">Número de Telefone:</label>
      <input type="tel" id="phone" :value="formData.phone" @input="$emit('update:phone', $event.target.value)" required class="form-control" />
    </div>
    <div class="form-group">
      <label>Área de Interesse:</label>
      <div class="radio-group">
        <div v-for="option in interestOptions" :key="option" class="radio-item">
          <input type="radio" :id="option" :value="option" :checked="formData.interest === option" @change="updateInterest(option)" />
          <label :for="option">{{ option }}</label>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['formData'],
  data() {
    return {
      interestOptions: [
        'Análise de Dados',
        'Atendimento ao Cliente',
        'Cibersegurança',
        'Desenvolvimento',
        'Design',
        'Finanças',
        'Inteligência Artificial',
        'Marketing',
        'Publicidade',
        'Recursos Humanos',
        'Relações Públicas',
        'Outro'
      ]
    };
  },
  methods: {
    updateInterest(option) {
      this.$emit('update:interest', option);
    }
  }
}
</script>

<style scoped>
.form-step {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.form-group {
  width: 100%;
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

.form-control {
  width: 163%;
  padding: 15px;
  font-size: 18px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.radio-group {
  display: flex;
  flex-direction: column;
}

.radio-item {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.radio-item input {
  margin-right: 5px;
}
</style>