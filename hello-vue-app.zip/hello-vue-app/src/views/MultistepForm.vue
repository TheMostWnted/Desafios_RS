<template>
  <div class="container">
    <div class="left-column">
      <img src="@/assets/cover.png" alt="Descrição da Imagem" class="left-image">
    </div>
    <div class="right-column">
      <!-- Progress Status -->
      <div class="progress-status">
        {{ progressStatus }}
      </div>
      <!-- Progress Bar Container -->
      <div class="progress-bar-container">
        <div class="progress-bar">
          <div class="progress" :style="{ width: progressWidth }"></div>
        </div>
      </div>
      <form @submit.prevent="handleSubmit" class="form-container">
        <div v-if="step === 1">
          <StepOne :formData="formData" @update:name="updateName" @update:email="updateEmail" />
        </div>
        <div v-if="step === 2">
          <StepTwo :formData="formData" @update:phone="updatePhone" @update:interest="updateInterest" />
        </div>
        <div v-if="step === 3">
          <StepThree :formData="formData" @update:message="updateMessage" @update:termsAccepted="updateTerms" />
        </div>
        <div class="navigation-buttons">
          <button type="button" @click="prevStep" v-if="step > 1" class="prev-button">
            &#8592; Passo Anterior
          </button>
          <button type="button" @click="nextStep" v-if="step < 3" class="next-button">
            Próximo
          </button>
          <button type="submit" v-if="step === 3" class="submit-button">
            Enviar
          </button>
        </div>
      </form>
      <p v-if="message">{{ message }}</p>
    </div>

     <!-- Modal -->
    <div v-if="showModal" class="modal">
      <div class="modal-content">
        <span class="close" @click="closeModal">&times;</span>
        <h2>Formulário Enviado</h2>
        <p>Formulário foi enviado com sucesso!</p>
        <div class="success-icon">&#10003;</div>
      </div>
    </div>    
  </div>
</template>

<script>
import StepOne from '../components/StepOne.vue';
import StepTwo from '../components/StepTwo.vue';
import StepThree from '../components/StepThree.vue';

export default {
  components: { StepOne, StepTwo, StepThree },
  data() {
    return {
      step: 1,
      formData: {
        name: '',
        email: '',
        phone: '',
        interest: '',
        message: '',
        termsAccepted: false,
      },
      message: '',
      showModal: false 
    };
  },
  computed: {
    progressWidth() {
      return (this.step / 3) * 100 + '%';
    },
    progressStatus() {
      return `${this.step} de 3 completo`;
    }
  },
  methods: {
    nextStep() {
      if (this.isValidStep(this.step)) {
        this.step++;
      }
    },
    prevStep() {
      this.step--;
    },
    handleSubmit() {
      if (this.isValidStep(this.step)) {
        this.showModal = true;
      }
    },
    closeModal() {
      this.showModal = false;
    },
    isValidStep(step) {
    switch (step) {
        case 1:
        // Validação do Passo 1: Nome completo e Endereço de email
        if (!this.formData.name || !this.formData.email) {
            this.message = 'Por favor, preencha todos os campos do passo 1.';
            return false;
        }
        if (!this.validEmail(this.formData.email)) {
            this.message = 'Por favor, insira um email válido.';
            return false;
        }
        break;
        case 2:
        // Validação do Passo 2: Número de telefone e Área de interesse
        if (!this.formData.phone || !this.formData.interest) {
            this.message = 'Por favor, preencha todos os campos do passo 2.';
            return false;
        }
        // Verificar se o número de telefone é válido
        if (isNaN(this.formData.phone)) {
            this.message = 'Por favor, insira um número de telefone válido.';
            return false;
        }
        break;
        case 3:
        // Validação do Passo 3: Checkbox de termos e mensagem opcional
        if (!this.formData.termsAccepted) {
            this.message = 'Precisa de aceitar os termos e condições.';
            return false;
        }
        break;
    }
        // Se tudo estiver correto, limpar a mensagem de erro
        this.message = '';
        return true;
    },
    validEmail(email) {
      // Expressão regular para validar o formato de um email
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },
    updateName(value) {
      this.formData.name = value;
    },
    updateEmail(value) {
      this.formData.email = value;
    },
    updatePhone(value) {
      this.formData.phone = value;
    },
    updateInterest(value) {
      this.formData.interest = value;
    },
    updateMessage(value) {
      this.formData.message = value;
    },
    updateTerms(value) {
      this.formData.termsAccepted = value;
    }
  }
}
</script>

<style>

@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');

html, body {
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%;
  font-family: 'Roboto', sans-serif;
}

#app {
  width: 100%;
  height: 100%;
}

.container {
  display: flex;
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
}

.left-column {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  margin: 0;
  padding: 0;
}

.right-column {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start; 
  padding: 20px;
  margin-left: 60px;
}

.left-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.progress-status {
  margin-bottom: 10px;
  font-size: 16px;
  font-weight: bold;
}

.progress-bar-container {
  width: 100%;
  display: flex;
  justify-content: flex-start; 
  margin-bottom: 20px;
}

.progress-bar {
  width: 60%;
  background-color: #e0e0e0;
  border-radius: 5px;
  overflow: hidden;
}

.progress {
  height: 10px;
  background-color: #20c997; 
  width: 0;
  transition: width 0.3s;
}

.form-container {
  width: 60%; 
  display: flex;
  flex-direction: column;
  align-items: flex-start; 
}

.navigation-buttons {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}

button {
  margin-right: 10px;
}

.prev-button {
  background: none;
  border: none;
  color: #000;
  font-size: 16px;
  cursor: pointer;
  display: flex;
  align-items: center;
}

.next-button {
  background-color: #20c997; 
  color: #fff;
  padding: 10px 20px;
  font-size: 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.submit-button {
  background-color: #20c997; 
  color: #fff;
  padding: 10px 20px;
  font-size: 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.modal {
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
  background-color: #fff;
  padding: 20px;
  border-radius: 4px;
  width: 80%;
  max-width: 500px;
  position: relative;
  text-align: center;
}

.close {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 24px;
  cursor: pointer;
}

.success-icon {
  font-size: 48px;
  color: #20c997; 
  margin-bottom: 10px;
}

</style>
